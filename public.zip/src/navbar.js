import React from "react";
function Navbar(propos) {
  return (
    <>
      <div class="container">
        <div class="row">
          <div class="col-sm-12 p-3 mb-2 bg-info text-dark border border-primary rounded ">
            <h1>
              <span>
                <i class="bi bi-cart4"></i>
              </span>{" "}
              Mobile accessories Cart
            </h1>
          </div>
        </div>
      </div>
    </>
  );
}
export default Navbar;
