import React from "react";

function Cart(propos) {
  return (
    <>
      <li class="list-group-item d-flex justify-content-between align-items-center mt-2">
        {propos.product}
        <span>
          {" "}
          <button class=" bg-success rounded ">1</button>{" "}
          <button
            onClick={() => propos.deleteitem(propos.product)}
            class=" bg-danger rounded "
          >
            X
          </button>
        </span>
      </li>
    </>
  );
}
export default Cart;
