import React from "react";
import Cards from "./cards";
import { useState } from "react";
import Cart from "./cart";
function Accessoriescontainer(propos) {
  const itemlist = [
    {
      name: "Airpods",
      price: 5000,
      instock: true,
      image:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSAhHaa8gRzkOpOetS_ctYfBLONPAmK2b4uVA&usqp=CAU",
    },
    {
      name: "Smart Watch",
      price: 8000,
      instock: true,
      image:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRIRjF3UKV2VEWn3nR-lJmHs3RWIoJccIqnxg&usqp=CAU",
    },
    {
      name: "Head Phones",
      price: 3000,
      instock: true,
      image:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTanuKKGe2MInj2dfGaOo2jydTFuFsLpW1oAw&usqp=CAU",
    },
    {
      name: "Power Bank",
      price: 2500,
      instock: true,
      image:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSjVUxPmDHqLG2x-EnsULVR9rGaY_4o3kDotA&usqp=CAU",
    },
    {
      name: "Fitness Bnd",
      price: 2000,
      instock: false,
      image:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRT_nsQMPaF8zDTClGDuwgpT2UYMEvmV4XGGg&usqp=CAU",
    },
    {
      name: "Speaker",
      price: 4000,
      instock: true,
      image:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQ_1C3tcwjhK0VUzO8nc42ELe4rLqgAVQMJw&usqp=CAU",
    },
  ];
  let [cartitem, additem] = useState([]);
  let [total, settotal] = useState(0);
  function addition(value) {
    additem([...cartitem, value.name]);
    console.log(settotal(total + value.price));
    settotal(total + value.price);
  }
  function removeitem(value) {
    const findex = cartitem.findIndex((value1) => value1.id === value.id);
    cartitem.splice(findex, 1);
    additem([...cartitem]);

    settotal(total - value.price);
  }
  return (
    <>
      <div class="container">
        <div class="row">
          <header class="d-flex justify-content-between ">
            <h5 className="text-primary ">
              Happy Shopping <i class="bi bi-emoji-smile"></i>
            </h5>
            <h5 className="text-warning">
              Your Cart({cartitem.length})<i class="bi bi-cart"></i>
            </h5>
          </header>
          {/* shopping card */}
          <div class="col-sm-9 border border-primary rounded d-flex flex-row flex-wrap justify-content-around ">
            {itemlist.map((item) => {
              return <Cards cardsproduct={item} add={addition}></Cards>;
            })}
          </div>
          {/* ---------CARTS----------- */}
          <div class="col-sm-3 border border-warning rounded">
            <ul class="list-group mt-2">
              {cartitem.map((item) => {
                return <Cart deleteitem={removeitem} product={item}></Cart>;
              })}
            </ul>
            <hr></hr>
            <h5> Toatl: {total}</h5>
          </div>
        </div>
      </div>
    </>
  );
}
export default Accessoriescontainer;
