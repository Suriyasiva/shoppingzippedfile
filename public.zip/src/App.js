import logo from "./logo.svg";
import "./App.css";
import Navbar from "./navbar";
import Accessoriescontainer from "./shoppingitemlist";

function App() {
  return (
    <>
      <Navbar></Navbar>
      <Accessoriescontainer></Accessoriescontainer>
    </>
  );
}

export default App;
