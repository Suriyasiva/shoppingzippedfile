import React from "react";
import "./App.css";
function Cards(propos) {
  function alerts(params) {
    alerts();
  }
  return (
    <>
      <div class="card mb-2 mt-2 " style={{ width: "15rem" }}>
        <img
          id="itemimage"
          src={propos.cardsproduct.image}
          class="card-img-top"
          alt={propos.cardsproduct.name}
        />
        <div class="card-body">
          <h5 class="card-title">{propos.cardsproduct.name}</h5>
          <p class="card-text">$ {propos.cardsproduct.price}</p>
          {/* disabling button by using ternary operator */}
          {propos.cardsproduct.instock ? (
            <button
              onClick={() => propos.add(propos.cardsproduct)}
              class="btn btn-primary"
            >
              <i class="bi bi-cart-check"></i> Add TO Cart
            </button>
          ) : (
            <button
              onClick={() => propos.clicked(propos.cardsproduct.price)}
              class="btn btn-primary"
              disabled
            >
              <i class="bi bi-cart-check"></i> Add TO Cart
            </button>
          )}
        </div>
      </div>
    </>
  );
}

export default Cards;
